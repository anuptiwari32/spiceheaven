import React from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Header from '../../Header/Header';
import moment from 'moment';
class ManageBookings extends React.Component {
    array = [];
    constructor(props) {
        super(props);
        this.state = {
            submitted: false,
            onDelete: ''
        }
        this.refresh = this.refresh.bind(this);
        this.onDelete = this.onDelete.bind(this);
    }

    componentDidMount = () => {
        var userData  = sessionStorage.getItem('userData');
        var data = JSON.parse(userData);
        this.loadRooms(data.userType==2?data.id:null);
    }

    onDelete = (e, id) => {
        if(confirm("Are you sure want to cancel ?")){
            var userData  = sessionStorage.getItem('userData');
            var data = JSON.parse(userData)
            const sendData = this.array.find((x)=>x.id == id);
            sendData.isCancelled = true;
            sendData.UserId = data.id,
                axios.put("http://localhost:52460/api/booking/cancelbooking/"+id, sendData
                
            )
            .then(response => {

                this.refresh(e);            
            });
            }
    }

    refresh = (e) => {
        var userData  = sessionStorage.getItem('userData');
        var data = JSON.parse(userData);
        this.loadRooms(data.userType==2?data.id:null);
    }

    loadRooms = (userId=null) => {

        var url = 'http://localhost:52460/api/booking/getbookings';
        if(userId!=null)
         url = 'http://localhost:52460/api/booking/getbookingsbyuser/'+userId;

        axios.get(url)
            .then(response => {
                this.array = response.data;
                console.log("inside component will mount ");

                this.setState({
                    submitted: true
                })
            });
    }
    render() {
        return (
            <div>
                <Header/>
                <div className="container">
                    <div className="row">
                        <h1>Manage Bookings</h1>
                    </div>

                    <div className="row">
                        <Link to={
                            {
                                pathname: "/add-booking"
                            }
                        }>
                        <i id='addRoom' className="fas fa-plus-circle fa-2x btn-circle"></i>
                        </Link>
                        <i className="fas fa-sync-alt fa-2x btn-circle" onClick={this.refresh}></i>
                    </div>
                    <div className="row">
                        <table className="table table-hover">
                            <thead className="thead-dark">
                                <tr>
                                    <th>
                                        Room Name
                                    </th>
                                    <th>
                                        Location
                                    </th>
                                    <th>
                                        Start Date
                                    </th>
                                    <th>
                                         End Date
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>Action</th>
                                </tr>
                            </thead>



                            {this.array.map((item, index) => (
                                <tbody>
                                    <tr>
                                        <td id={item.roomName} >{item.roomName} </td> {/* sel id*/}
                                        <td>{item.roomLocation}</td>
                                        <td>{moment(item.startDateTs).format('DD-MM-YYYY hh:mm a')} </td>
                                        <td>{moment(item.endDateTs).format('DD-MM-YYYY hh:mm a')} </td>
                                        <td> {item.isCancelled === false &&
                                            <span className="badge badge-pill badge-success">Booked</span>}
                                            {item.isCancelled === true &&
                                                <span className="badge badge-pill badge-danger">Cancelled</span>
                                            }
                                        </td>
                                        <td>
                                        {item.isCancelled === false &&
                                           
                                            <button type='button' className='btn btn-outine btn-danger' id={`${item.roomName}_cancel`} onClick={(e) => {
                                                this.onDelete(e, item.id)
                                            }}>
                                            <i className="fas fa-trash-alt btn-circle" ></i> Cancel
                                            </button>}
                                        </td>
                                    </tr>
                                </tbody >))}
                            <tfoot>
                                <tr>
                                    <td colSpan="4">
                                    </td>
                                </tr>
                            </tfoot>
                        </table >
                    </div >

                </div >
            </div >
        );
    }
}
export { ManageBookings as ManageBookings };