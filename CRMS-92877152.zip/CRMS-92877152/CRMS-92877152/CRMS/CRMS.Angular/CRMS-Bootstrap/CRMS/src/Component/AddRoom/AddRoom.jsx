import React from 'react';
import Header from '../../Header/Header';
import axios from 'axios';
class AddRoom extends React.Component  {
    array = [];
    roomData = {};
    names = ['isActive','location','name','capacity','roomTypeId'];
    constructor(props) {
        super(props);
    
        this.state = {
            submitted: false,
            onDelete: '',
            name:'',
            location:'',
            isActive:'',
            capacity:'',
            roomTypeId:''
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }
  
    handleChange = (event) => {
        const name = event.target.name;
        let value = event.target.value;
        if(name==="isActive")
        value = value==="1"?true:(value==="0"?false:"")
        this.roomData[name] = value;
        this.setState({...this.state,[name]:value});
       }

    componentDidMount = () => {
        console.log(this.props);
        if(this.props.location.editButton)
        {
            this.setState({...this.state,...this.props.location.myCustomProps.item});
            this.names.map(name=>{
                this.roomData[name]= this.props.location.myCustomProps.item[name];
            })
        }
        var userData  = sessionStorage.getItem('userData');
        var data = JSON.parse(userData);
        this.loadRooms(data.userType==2?data.id:null);
    }


    loadRooms = () => {
        axios.get('http://localhost:52460/api/room/getroomtypes')
            .then(response => {
                this.array = response.data;
                console.log("inside component will mount ");

                this.setState({
                    submitted: true
                })
            });
    }

    handleValidation = () => {
      let formIsValid = true;
      if(this.roomData['name'] == null ||this.roomData['name']=='')
      {
        alert('Please enter room name');
        formIsValid = false;
      }
      else if(this.roomData['location'] == null ||this.roomData['location']=='')
      {
        alert('Please enter location');
        formIsValid = false;
      }
      else if(this.roomData['capacity'] == null ||this.roomData['capacity']=='')
      {
        alert('Please enter capacity');
        formIsValid = false;
      }
      else if(this.roomData['isActive'] == null ||this.roomData['isActive']=='')
      {
        alert('Please select status');
        formIsValid = false;
      }
      else if(this.roomData['roomTypeId'] == null ||this.roomData['roomTypeId']=='')
      {
        alert('Please select room type');
        formIsValid = false;
      }
      return formIsValid;
    }
  
    handleSubmit(e){
        e.preventDefault();
        if(this.handleValidation())
        {
        var userData  = sessionStorage.getItem('userData');
        var pData = JSON.parse(userData);

        var data = this.roomData;
        data.createdBy = pData.firstname+" "+pData.lastname;
        if(this.props.location.editButton)
        {
            data.id = this.props.location.myCustomProps.item.id;
        }
        else
        {
            data.id = 0;
        }
        axios.post('http://localhost:52460/api/room/save',data)
        .then(response => {
            console.log(response.data);
            this.setState({
                submitted: true
            });
            this.props.history.push('/manage-rooms');
        }).catch(err=>{
          alert('error in booking');
        });   
      }
      }
    
render(){
  return (
    <div>
    <Header/>
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h3 className="text-center">{this.props.location.editButton?'Edit':'Add'} Room</h3>
        </div>
      <div className="card-body">
        <form action="" className='form_Add'>
          <div className="row">
            <label htmlFor="" className='col-md-12'>Room Name</label>
            <input type="text" name="name" maxLength={100} value={this.state.name} className=' form-control mb-3' onChange={this.handleChange}  placeholder='Room Name' id='name'/>
          </div>
          <div className="row">
            <label htmlFor="" className='col-md-12'>Location</label>
            <input type="text" name="location" maxLength={100} value={this.state.location} className='form-control  mb-3' placeholder='Location' id='location' onChange={this.handleChange} />
          </div>
          
          <div className="row ">
            <label htmlFor="" className='col-md-12'>Capacity</label>
            <input type="text" name="capacity" maxLength={10} value={this.state.capacity} className='form-control mb-3'placeholder='Capacity' id='capacity' onChange={this.handleChange} />
            
            <label htmlFor="">Room Type</label>
              <select value={this.state.roomTypeId} name="roomTypeId" className='form-control  mb-3' id='type' onChange={this.handleChange} >
                <option value="">Choose</option>
                {this.array.map((item, index) => (
                <option key={'sel'+index} value={item.id}>{item.roomTypeName}</option>
              ))}
            </select>

          </div>
          <div className="row ">
          <label htmlFor="">Is Active</label>
              <select name='isActive' value={this.state.isActive===true?'1':(this.state.isActive===false?'0':'')}  className='form-control  mb-3' id='status' onChange={this.handleChange}>
                <option value="">Choose</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
              </select>
          </div>
          
          <div className="row ">
            <div className="col-6 btn-login mt-2">
              <button type="button"  id='addRoomButton' className='btn btn-success' onClick={this.handleSubmit}>Save</button>
              <button type="button"  className='btn btn-warning mx-2'  onClick={()=>this.props.history.push('/manage-rooms')} >Cancel</button>
            </div>
            <div className="col-6"></div>

          </div>
        </form>
      </div>
    </div>

  </div>
  </div>
  )
}
}
export  { AddRoom as AddRoom}