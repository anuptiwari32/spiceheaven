import React from "react";

import { Route, Router ,Switch} from "react-router-dom";
import { ManageRooms } from "../Component/ManageRooms/ManageRooms";
import { createBrowserHistory } from "history";
import { Login } from "../Component/Login/Login";
import { Register } from "../Component/Register/Register";
import { Dashboard } from "../Component/Dashboard/DashBoard";
import { ManageBookings } from "../Component/ManageBookings/ManageBookings";
import { AddRoom } from "../Component/AddRoom/AddRoom";
import { AddBooking } from "../Component/AddBooking/AddBooking";


const history = createBrowserHistory()

const ProtectedComponent = () => {
  if (authFails)
    return <Redirect to='/login'  />
  return <div> My Protected Component </div>
}

class App extends React.Component {

    constructor(props) {
        super(props);
    }

  change = () => {
    console.log("----in app.js----------");
  };

  onlinkChange = () => {
    console.log("");
  };

  CheckUser = () => {
    if(history.location.pathname === "/logout")
    {
      sessionStorage.removeItem('userData');
      history.push('/') ;
    }
    
   var userData = sessionStorage.getItem('userData');
    if(userData!==undefined && userData != null )
    {
      var data = JSON.parse(userData)
      if(history.location.pathname === "/" || history.location.pathname==="/register")
        history.push('/dashboard')
    }
    else
    history.push('/') ;

  };

  componentDidMount()
  {
    this.CheckUser();
  }

  render() {
    return (

      <Router history={history}>
        <Switch>

        <Route exact path="/" component={Login} />
        <Route exact path="/register" component={Register} />
        <Route path="/dashboard" component={ Dashboard} />
        <Route path="/manage-rooms" component={ ManageRooms} />
        <Route path="/manage-bookings" component={ ManageBookings} /> 
        <Route path="/add-room" component={ AddRoom} />
        <Route path="/add-booking" component={ AddBooking} />

        </Switch>
      </Router>

    );
  }
}

export { App };
