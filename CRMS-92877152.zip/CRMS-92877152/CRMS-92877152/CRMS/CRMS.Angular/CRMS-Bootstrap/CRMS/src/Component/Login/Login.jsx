import React from 'react'
import axios from 'axios';
class Login extends React.Component {
    loginData = {};
    array = [];
    constructor(props) {
        super(props);
        this.state = {
            submitted: false,
            onDelete: ''
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

     handleChange = (event) => {
      const name = event.target.name;
      const value = event.target.value;
      this.loginData[name] = value;
    }

    handleSubmit(e){
      e.preventDefault();
      if(this.handleValidation())
      {
      axios.post('http://localhost:52460/api/account/login',this.loginData)
      .then(response => {
          this.array = response.data;
          console.log(response.data);
          sessionStorage.setItem('userData',JSON.stringify(this.array));
          this.setState({
              submitted: true
          });
          this.props.history.push('/dashboard');

      }).catch(err=>{
        alert('Invalid username password combination');
      });    
      }
    }

    handleValidation = () => {
      let formIsValid = true;
      if(this.loginData['username'] == null ||this.loginData['username']=='')
      {
        alert('Please enter user name');
        formIsValid = false;
      }
      
      else if(this.loginData['password'] == null ||this.loginData['password']=='')
      {
        alert('Please enter password');
        formIsValid = false;
      }
    
      return formIsValid;
    }

    componentDidUpdate(oldProps,prevState)
    {
      console.log(this.array);
    }
    componentDidMount = () => {
    }
    render(){
    return (
      <div className="container">
        <div className="card ">
            <div className="card-header text-center">
              <h3 id='heading'>CRMS</h3>
            </div>
            <div className="card-body text-center">
            <form>
              <div className="row">
                <input type="text" name="username" maxLength={100} id='username' onChange={this.handleChange} placeholder='username' className='form-control mb-3' />
              </div>
              <div className="row">
                <input type="password" id='password' maxLength={50} name="password" onChange={this.handleChange} placeholder='password' className='form-control mb-3' />
              </div>
              <div className="row">
                <div className="col-md-8">
                  <input type="checkbox" id="checkbox" name="checkbox" value="checkbox" />
                  <label>Remamber me</label>
                </div>
              </div>
              <div className="row ">
                <div className="col-6 btn-login mt-2">
                  <button type="submit" value="Submit" id='login' className='btn btn-primary' onClick={this.handleSubmit}>Login</button>
                  <button type="button" value="Submit" id='register'  className='btn btn-primary mx-2' onClick={()=>this.props.history.push('/register')} >Register</button>
                </div>
                <div className="col-6"></div>

              </div>
            </form>
          </div>

        </div>

      </div>

    );
    }
}

export  { Login as Login}
