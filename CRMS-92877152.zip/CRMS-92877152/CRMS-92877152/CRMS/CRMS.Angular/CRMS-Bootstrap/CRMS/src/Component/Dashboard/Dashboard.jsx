import React from 'react';
import axios from 'axios';
import Header from '../../Header/Header';
import History from '../../Views/history/History';

class Dashboard extends React.Component {
  array = [];
  upcoming = [];
    constructor(props) {
        super(props);
        this.state = {
            submitted: false,
            onDelete: ''
        }
        this.refresh = this.refresh.bind(this);
    }

    componentDidMount = () => {
      var userData  = sessionStorage.getItem('userData');
        var data = JSON.parse(userData);
        this.loadRooms(data.userType==2?data.id:null);
      }
    refresh = (e) => {      
      var userData  = sessionStorage.getItem('userData');
      var data = JSON.parse(userData);
      this.loadRooms(data.userType==2?data.id:null);
    }

    loadRooms = (userId = null) => {
      var url = 'http://localhost:52460/api/booking/getbookings';
      if(userId!=null)
       url = 'http://localhost:52460/api/booking/getbookingsbyuser/'+userId;

        axios.get(url)
            .then(response => {
                this.array = response.data;
                this.array.map(item=>{
                  if(new Date(item.startDateTs).getTime() > new Date().getTime())
                  {
                    this.upcoming.push(item);
                  }
                })
                this.setState({
                    submitted: true
                })
            });
    }
  render(){
  return (
    <div>      
      <Header />
      <div className="container">
        <div className="row">
          <div className="col-4">
            <h4 className='text-muted my-1'>Upcoming</h4>
            {this.upcoming.map((item, index) => (
               (!item.isCancelled &&
                <History item={item} />)           
                ))
              }
          </div>
          <div className="col-4">
            <h4 className='text-muted my-1'>Cancelled</h4>
            {this.array.map((item, index) => (
              (item.isCancelled &&
                <History item={item} />)           
                ))
              }            
          </div>
          <div className="col-4">
            <h4 className='text-muted my-1'>Booking History</h4>
            {this.array.map((item, index) => ( 
                <History item={item} />           
              ))
             }
                
          </div>
        </div>
      </div>
    </div>
  );
  }
}

export  { Dashboard as Dashboard }