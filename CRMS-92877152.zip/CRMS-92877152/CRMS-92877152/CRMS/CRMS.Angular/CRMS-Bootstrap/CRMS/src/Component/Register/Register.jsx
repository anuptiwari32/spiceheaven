import axios from 'axios';
import React from 'react';

class Register extends React.Component {
  registerData = {};
  constructor(props) {
      super(props);
      this.state = {
          submitted: false,
      }
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
  }
 
  handleChange = (event) => {
    
    const name = event.target.name;
    const value = event.target.value;
    this.registerData[name] = value;
    if(name === 'Email')
    this.registerData["UserName"] = value;
  }

  componentDidUpdate()
  {
    console.log(this.registerData);
  }

  handleValidation = () => {
    let formIsValid = true;
    if(this.registerData['EmpId'] == null ||this.registerData['EmpId']=='')
    {
      alert('Please enter employee id');
      formIsValid = false;
    }
    else if(this.registerData['Firstname'] == null ||this.registerData['Firstname']=='')
    {
      alert('Please enter First Name');
      formIsValid = false;
    }
    else if(this.registerData['Lastname'] == null ||this.registerData['Lastname']=='')
    {
      alert('Please enter Last Name');
      formIsValid = false;
    }
    else if(this.registerData['UserType'] == null ||this.registerData['UserType']=='')
    {
      alert('Please select User Typer');
      formIsValid = false;
    }
    else if(this.registerData['Password'] == null ||this.registerData['Password']=='')
    {
      alert('Please enter password');
      formIsValid = false;
    }
    
    else if(this.registerData['ConfirmPassword'] == null || this.registerData['ConfirmPassword']=='' )
    {
      alert('Please enter confirm password');
      formIsValid = false;
    }
    else if(this.registerData['Password'] != this.registerData['ConfirmPassword'] )
    {
      alert('Password and confirm password should match');
      formIsValid = false;
    }
    else if(this.registerData['PhoneNumber'] == null || this.registerData['PhoneNumber']=='' )
    {
      alert('Please enter phone number');
      formIsValid = false;
    }
    else if(this.registerData['EmpAddress'] == null || this.registerData['EmpAddress']=='' )
    {
      alert('Please enter your location');
      formIsValid = false;
    }
    return formIsValid;
  }

  handleSubmit(e){
    e.preventDefault();
    if(this.handleValidation())
    {
    var data = this.registerData;
    axios.post('http://localhost:52460/api/account/registerUser',data)
    .then(response => {
        this.array = response.data;
        console.log(response.data);
        this.setState({
            submitted: true
        });
        this.props.history.push('/');
    });  
    }  
  }



  render()
  {
  return (
    <div className="container">
        <div className="sub_main">
            <div className="card">
              <div className="card-header text-center">
                          <h3>Register</h3>
                      </div>  
                <div className="card-body">
                      
                      <form className='form'>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start  col-md-12'>Emp ID</label>
                          <input type="text" id='txtempid' name="EmpId" maxLength={20} placeholder='Employee Id' className='mb-3 form-control' onChange={this.handleChange} />
                        </div>
                        <div className="row r-row">
                          <div className="col-6 ">
                            <label className='d-flex justify-content-start '>Firstname</label>
                            <input type="text" id='txtFirstname' maxLength={50} name="Firstname" placeholder='Firstname' className='mb-3 form-control' onChange={this.handleChange} />
                          </div>
                       
                          <div className="col-6">
                            <label className='d-flex justify-content-start'> Lastname</label>
                            <input type="text" id='txtLastname' name="Lastname" maxLength={50} placeholder='Lastname' className='mb-3 form-control' onChange={this.handleChange} />
                          </div>
                        </div>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start col-md-12'> User Type</label>
                          <select  className='mb-3 form-control' id='txtUserType' name='UserType' onChange={this.handleChange} >
                            <option value="">Choose</option>
                            <option value="1">Facility Manager</option>
                            <option value="2">Employee</option>
                          </select>
                        </div>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start col-md-12'>Email</label>
                          <input type="text" id='txtemail' name="Email" maxLength={100} placeholder='Email' className='mb-3 form-control' onChange={this.handleChange} />
                        </div>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start col-md-12'>Password</label>
                          <input type="password" id='txtPassword' maxLength={50} name="Password" placeholder='Password' className='mb-3 form-control' onChange={this.handleChange}/>
                        </div>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start col-md-12'>Confirm Password</label>
                          <input type="password" id='txtConfirmPassword' maxLength={50} name="ConfirmPassword" placeholder='Confirm Password' className='mb-3 form-control' onChange={this.handleChange}/>
                        </div>
                        <div className="row r-row">
                          <label className='d-flex justify-content-start col-md-12'>Mobile No.</label>
                          <input type="text" id='txtmobile' name="PhoneNumber" maxLength={13} placeholder='Mobile No.' className='mb-3 form-control' onChange={this.handleChange}/>
                        </div>
                       <div className="row r-row">
                        <label className='d-flex justify-content-start col-md-12'>Address</label>
                        <textarea type="text" id='txtAddress' name="EmpAddress" maxLength={200} placeholder='Address ' className='mb-3 form-control' onChange={this.handleChange}/>
                        </div>
                        <div className="col-6 btn-login mt-2">
                          <button type="button" value="Submit" id='registerUser' className='btn btn-success' onClick={this.handleSubmit}>Register </button>
                          <button type="button" value="Submit" id='loginButton'  className='btn btn-primary mx-2'  onClick={()=>this.props.history.push('/')}>Login</button>
                      </div>
                  </form>
          </div>
        </div>
      </div>
    </div>
  )
  }
}

export  { Register as Register}