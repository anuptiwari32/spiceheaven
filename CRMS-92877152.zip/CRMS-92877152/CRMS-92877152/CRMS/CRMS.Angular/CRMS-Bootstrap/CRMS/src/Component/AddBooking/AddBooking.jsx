import React from 'react';
import Header from '../../Header/Header';
import axios from 'axios';
import moment from 'moment';

class AddBooking extends React.Component {
    array = [];
    registerData={};
    constructor(props) {
        super(props);
        this.state = {
            submitted: false,
            startDate:'',
            endDate:'',
            startTime:'',
            endTime:'',
            onDelete: ''
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount = () => {
        var userData  = sessionStorage.getItem('userData');
        var data = JSON.parse(userData);
        this.loadRooms(data.userType==2?data.id:null);
    }

    componentWillUnmount() {
        // fix Warning: Can't perform a React state update on an unmounted component
        this.setState = (state,callback)=>{
            return;
        };
    }
    componentDidUpdate()
    {
        if( (this.state.startDate!=this.state.endDate || this.state.startTime != this.state.endTime) && 

            new Date(this.state.startDate+" "+this.state.startTime).getTime() > new Date(this.state.endDate+" "+this.state.endTime).getTime())
        {
            alert('Please enter end date greater than start date');
            this.setState ({...this.state,endDate:'',endTime:''});
        }
    }

    handleChange = (event) => {
    
        const name = event.target.name;
        const value = event.target.value;
        this.registerData[name] = value;
        
        if(name==="startDate")
        {
            const newDate = moment(value).format('YYYY-MM-DD');
            this.setState ({...this.state,startDate:newDate});
        }
        else if(name==="startTime")
        {
            this.setState ({...this.state,startTime:value});
            console.log(value);
        }
        else if(name==="endDate")
        {
            const endate = moment(value).format('YYYY-MM-DD');
            this.setState ({...this.state,endDate:endate});
        }
        else if(name==="endTime")
        {
            this.setState ({...this.state,endTime:value});

        }
      }

      handleValidation = () => {
        let formIsValid = true;
        if(this.registerData['roomId'] == null ||this.registerData['roomId']=='')
        {
          alert('Please select room id');
          formIsValid = false;
        }
        else if(this.registerData['startDate'] == null ||this.registerData['startDate']=='')
        {
          alert('Please select start date');
          formIsValid = false;
        }
        else if(this.registerData['startTime'] == null ||this.registerData['startTime']=='')
        {
          alert('Please select start time');
          formIsValid = false;
        }
        else if(this.registerData['endDate'] == null ||this.registerData['endDate']=='')
        {
          alert('Please select end date');
          formIsValid = false;
        }
        else if(this.registerData['startTime'] == null ||this.registerData['startTime']=='')
        {
          alert('Please select end time');
          formIsValid = false;
        }
        return formIsValid;
      }
    
    handleSubmit(e){
        e.preventDefault();
        if(this.handleValidation())
        {
        var userData  = sessionStorage.getItem('userData');
        var pData = JSON.parse(userData);
        var data = this.registerData;

        var sendData = {
        startDateTs : data.startDate+" "+data.startTime,
        endDateTs : data.endDate+" "+data.endTime,
        userId : pData.id,
        bookedBy : pData.firstname+" "+pData.lastname,
        roomId : data.roomId
        }

        axios.post('http://localhost:52460/api/booking/save',sendData)
        .then(response => {
            console.log(response.data);
            this.setState({
                submitted: true
            });
            this.props.history.push('/manage-bookings');
        }).catch(err=>{
          alert('Selected Room not available');
        });    
        }
      }

    loadRooms = () => {
        var url = 'http://localhost:52460/api/room/getActiveRooms';
       
        axios.get(url)
            .then(response => {
                this.array = response.data;
                console.log("inside component will mount ");

                this.setState({
                    submitted: true
                })
            });
    }
render(){
  return (
    <div>
    <Header/>
    <div className="container">
      <div className="card">
      <div className="card-header">
            <h3>New Booking</h3>
          </div>
        <div className="card-body">
         
          <form action="">
            <div className="row booking_form">
              <label className='d-flex justify-content-start col-md-12'> Room</label>
              <select  className='form-control mb-3' onChange={this.handleChange} id='roomName' name='roomId'>
              <option value="">Select Room</option>
              {this.array.map((item, index) => (
                <option key={'sel'+index} value={item.id}>{item.name}</option>
              ))}
               
              </select>
            </div>
            <div className=" booking_form">

              <label className='col-6'>Start Date
                <input value={this.state.startDate} type="date" name="startDate" id='startDate' onChange={this.handleChange} className='form-control mb-3 mx-1' />
              </label>
              <label className='col-6'> 
                <input type="time" name="startTime" id='startTime' value={this.state.startTime} onChange={this.handleChange} className='form-control  mb-3' />
              </label>
            </div>

            <div className=" booking_form">
                <label className='col-6'> End Date
                    <input type="date" value={this.state.endDate} name="endDate" id='endTime' onChange={this.handleChange} className= 'form-control mb-3 mx-1' />
                </label>
                <label className='col-6'> 
                    <input type="time" name="endTime" value={this.state.endTime} id='endTime' onChange={this.handleChange} className='form-control mb-3' />
                </label>
            </div>
            <div className="col-6 btn-login mt-2">
                <button type="button" value="Submit" id='bookSubmit' className='btn btn-success mx-2' onClick={this.handleSubmit}>Save </button>
                <button type="submit" value="Submit" id='cancelButton'  className='btn btn-warning mx-2' onClick={()=>this.props.history.push('/manage-bookings')} >Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    </div>
  )
}
}

export  { AddBooking as AddBooking};