import React from 'react';

const Header = () => {

    var userData = sessionStorage.getItem('userData');
    if(userData!==undefined && userData!=null )
    {
      var data = JSON.parse(userData);
    }

  return (
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
  <a className="navbar-brand" href="/">CRMS</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNavDropdown">
    <ul className="navbar-nav">
      <li className="nav-item active">
        <a className="nav-link" href="/dashboard" id='dashboard'><i className="fas fa-tachometer-alt"></i> DASHBOARD <span className="sr-only">(current)</span></a>
      </li>
      {data!=null && data!=undefined && data.userType == 1 &&
      <li className="nav-item">
        <a className="nav-link" href="/manage-rooms" id='manageRooms'><i className="fas fa-door-open"></i> MANAGE ROOMS</a>
      </li>
        }
      <li className="nav-item">
        <a className="nav-link" href="/manage-bookings" id='booking'><i className="fas fa-book"></i> BOOKINGS</a>
      </li>
    </ul>
    <ul className='navbar-nav flex-row ml-md-auto d-none d-md-flex'>
      <li className="nav-item dropdown left">
          <a className="nav-link dropdown-toggle" href="#" id="user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i className="fas fa-user-circle"></i>
          </a>
          <div className="dropdown-menu " aria-labelledby="user-dropdown">
            <a className="dropdown-item" href="#">{`Logged in as ${data!=null&& data!=undefined && data.userName}`}</a>
            <div className="dropdown-divider"></div>
            <a className="dropdown-item" id='logout' href="/logout">Logout</a>
          </div>
        </li>
    </ul>  
  </div>
</nav>
  )
}

export default Header
