import React, { useEffect, useState } from 'react';
import moment from 'moment';

function History(props) {
  return (
    <div className='row'>
        <div className={'col-md-12  my-2 px-2 dash-row ' +(props.item.isCancelled?' ':' bg-green')}>
            <span  id={props.item.roomName+(props.item.isCanecelled?'_cancelled':'_upcoming')}>{props.item.roomName}</span><br />
            <span ><b>Location: </b>{props.item.roomLocation}</span><br />
            <span ><b>Booked From: </b>{moment(props.item.startDateTs).format('DD-MM-YYYY hh:mm A')+" To "+ moment(props.item.endDateTs).format('DD-MM-YYYY hh:mm A')}</span><br />
            <span ><b>Booked By: </b>{props.item.bookedBy}</span>
        </div>
    </div>
  )
}

export default History