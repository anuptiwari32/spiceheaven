﻿using Autofac;
using Autofac.Integration.WebApi;
using CRMS.Providers;
using log4net;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.DataHandler.Encoder;
using Microsoft.Owin.Security.Jwt;
using Microsoft.Owin.Security.OAuth;
using Owin;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web;
using System.Web.Http;

[assembly: OwinStartup(typeof(CRMS.Startup))]
namespace CRMS
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();
            WebApiConfig.Register(config);

            app.UseCors(CorsOptions.AllowAll);

     
            var builder = new ContainerBuilder();



            builder.RegisterType<Uow>().As<IUow>();

  
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());
            builder.Register(c => LogManager.GetLogger("CRMSLogger")).As<ILog>(); // Log4Net Dependency Injection


        
            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);

            // app.UseCors(CorsOptions.AllowAll);
            app.UseWebApi(config);


        }
    }
}