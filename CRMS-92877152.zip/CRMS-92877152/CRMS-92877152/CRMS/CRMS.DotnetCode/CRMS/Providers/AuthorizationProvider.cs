﻿using Data;
using Data.Entity;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OAuth;
using Repository;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;

namespace CRMS.Providers
{
    public class AuthorizationProvider : OAuthAuthorizationServerProvider
    {
         IUow _uow;
        public AuthorizationProvider()
        {
            _uow = new Uow();
        }

        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
            return Task.FromResult<object>(null);
        }
       
    }
}