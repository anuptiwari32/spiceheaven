﻿using Data.Entity;
using Data.ViewModel;
using log4net;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace CRMS.Controllers
{
    //[RoutePrefix("Room")]
    public class RoomController : BaseApiController
    {
        private IUow _uow;
        private ILog _log;

        public RoomController(IUow uow, ILog log)
        {
            _uow = uow;
            _log = log;
        }

        public async Task<IHttpActionResult> GetRooms()
        {
            return Ok(await this._uow.RoomRepository.Get());
        }

        public async Task<IHttpActionResult> GetActiveRooms()
        {
            try
            {
                return Ok(await this._uow.RoomRepository.GetActiveRooms());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        public async Task<IHttpActionResult> GetRoomTypes()
        {
            try
            {
                return Ok(await this._uow.RoomTypeRepository.Get());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        public async Task<IHttpActionResult> GetRoomsLookup()
        {
            
            return Ok();
        }

       [HttpPost]
        public async Task<IHttpActionResult> Save(ConfreneceRoom room)
        {

            try
            {
                var result = await _uow.RoomRepository.Store(room);

                if (result != null)
                    return Ok(result);
                else
                    return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        }

        [HttpDelete]
        public async Task<IHttpActionResult> Delete(long id)
        {
            await _uow.RoomRepository.Delete(id);
            await _uow.SaveAsync();
            return Ok();
        }

    }
}
