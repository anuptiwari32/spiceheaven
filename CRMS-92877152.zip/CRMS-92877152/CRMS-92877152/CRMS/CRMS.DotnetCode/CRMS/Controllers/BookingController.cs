﻿using AutoMapper;
using CRMS.Models;
using Data.Entity;
using Data.ViewModel;
using log4net;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace CRMS.Controllers
{
    public class BookingController : BaseApiController
    {
        private readonly IUow _uow;
        private readonly ILog _log;

        public BookingController(IUow uow, ILog log)
        {
            _uow = uow;
            _log = log;
        }
        
       public async Task<IHttpActionResult> GetBookings()
        {
            try { 
                List<BookingResponse> bookingResponses = new List<BookingResponse>();

                var result = await this._uow.BookingRepository.Get();
                if (result != null && result.Any())
                {
                    result.ToList().ForEach(res => bookingResponses.Add(new BookingResponse
                    {
                        Id = res.Id,
                        RoomName = res.ConfreneceRoom.Name,
                        RoomId = res.RoomId,
                        CancelledOnTs =  (DateTime)res.ModifiedTs,
                        IsCancelled = res.IsCancelled,
                        StartDateTs = (DateTime)res.StartDateTs,
                        EndDateTs = (DateTime)res.EndDateTs,
                        BookedBy = res.CreatedBy,
                        UserId = res.UserId,
                        RoomLocation = res.ConfreneceRoom.Location,
                        TransactionId = res.TransactionId,
                    })); ;
                    return Ok(bookingResponses);
                }
                else
                {
                    return BadRequest();

                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());

            }
        }
        [Route("api/booking/getbookingsbyuser/{userId}")]
        public async Task<IHttpActionResult> GetBookingsByUser(string userId)
        {
            try
            {
                var result = await this._uow.BookingRepository.GetBookings(userId);
                List<BookingResponse> bookingResponses = new List<BookingResponse>();
                if (result != null && result.Any())
                {
                    result.ToList().ForEach(res => bookingResponses.Add(new BookingResponse
                    {
                        Id = res.Id,
                        RoomName = res.ConfreneceRoom.Name,
                        RoomId = res.Id,
                        CancelledOnTs = (DateTime)res.ModifiedTs,
                        IsCancelled = res.IsCancelled,
                        StartDateTs = (DateTime)res.StartDateTs,
                        EndDateTs = (DateTime)res.EndDateTs,
                        BookedBy = res.CreatedBy,
                        UserId = res.UserId,
                        RoomLocation = res.ConfreneceRoom.Location,
                        TransactionId = res.TransactionId,
                    })); ;
                    return Ok(bookingResponses);
                }
                else {
                    return BadRequest();
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());

            }
        }

        public async Task<IHttpActionResult> GetCurrentMonthBookings(string userId = "")
         {
				return null;
        }


       [HttpPost]
        public async  Task<IHttpActionResult> Save(BookingViewModel booking)
        {

            try
            {
                await _uow.BookingRepository.SaveBooking(booking);
                 return Ok();
            
            }
            catch (Exception e)
            {
                return BadRequest(e.Message.ToString());
            }
        } 
		// write code
        [HttpPut]
        public async Task<IHttpActionResult> CancelBooking(int id, Booking booking) //await
		{
            try
            {
                await _uow.BookingRepository.CancelBooking(booking);
                return Ok();
            }
            catch (Exception e)
            {
                _log.Error(e.Message.ToString());
                return BadRequest(e.Message.ToString());
            }

        }


        [HttpDelete]
        public async Task<IHttpActionResult> Delete(long id) //await
		{
            await _uow.BookingRepository.DeleteBooking(id);
            return Ok();
        } 
    }
}
