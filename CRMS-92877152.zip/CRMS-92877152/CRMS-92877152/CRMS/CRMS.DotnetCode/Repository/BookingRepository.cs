﻿using Data;
using Data.Entity;
using Data.ViewModel;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class BookingRepository : GenericRepository<Booking>, IBookingRepository
    {
        private readonly CRMSDbContext _dBContext;
        public BookingRepository(CRMSDbContext dbContext) : base(dbContext)
        {
            _dBContext = dbContext;
        }

        public  async Task DeleteBooking(long id)
        {
            var booking = await _dBContext.Bookings.FindAsync(id).ConfigureAwait(false);;
            _dBContext.Bookings.Remove(booking);
            await  _dBContext.SaveChangesAsync().ConfigureAwait(false); 

        }


        public async Task CancelBooking(Booking booking)
        {
            var booking_m = _dBContext.Bookings.Find(booking.Id);
            var user = (User)_dBContext.Users.Where(x => x.Id.Equals(booking.UserId)).FirstOrDefault();
            if (user != null)
            {
                booking_m.IsCancelled = true;
                booking_m.ModifiedBy = user.Firstname+" "+user.Lastname;
                booking_m.ModifiedTs = DateTime.Now;
         
            }
            await _dBContext.SaveChangesAsync().ConfigureAwait(false);

        }

        public async Task<IList<Booking>> GetBookings(string userId= null)
        {
            return await _dBContext.Bookings.Where(x => x.UserId.Equals(userId)).ToListAsync();
        }

        public async Task SaveBooking(BookingViewModel booking)
        {
            var user = (User)_dBContext.Users.Where(x => x.Id.Equals(booking.UserId)).FirstOrDefault();
            var room = _dBContext.ConfreneceRoom.Where(x => x.Id.Equals(booking.RoomId)).FirstOrDefault();

            if (await IsRoomAvailable(booking))
            {
                Save(new Booking {
                    TransactionId = Guid.NewGuid(),
                    RoomId = booking.RoomId,
                    StartDateTs = booking.StartDateTs,
                    EndDateTs = booking.EndDateTs,
                    CreationTs = DateTime.Now,
                    ModifiedTs = DateTime.Now,
                    ModifiedBy = user.Firstname + " " + user.Lastname,
                    UserId = booking.UserId,
                    CreatedBy = user.Firstname+" "+user.Lastname,
                    StatusType = Data.Enum.StatusType.Enabled
                 
                });
            }
            else
            {
                throw new Exception("Selected room is not available!!!!");
            }
        }

        private async Task<bool> IsRoomAvailable(BookingViewModel booking)
        {
            var room = await _dBContext.Bookings.FirstOrDefaultAsync(x => x.RoomId.Equals(booking.RoomId) && x.StartDateTs >= booking.StartDateTs && x.EndDateTs <=booking.EndDateTs).ConfigureAwait(false);
            return room== null;
        }
    }
}
