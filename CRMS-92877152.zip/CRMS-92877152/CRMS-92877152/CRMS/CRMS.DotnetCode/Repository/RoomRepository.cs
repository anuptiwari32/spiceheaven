﻿using Data;
using Data.Entity;
using Data.Enum;
using Data.ViewModel;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class RoomRepository : GenericRepository<ConfreneceRoom>, IRoomRepository
    {
        private readonly CRMSDbContext _dBContext;
        public RoomRepository(CRMSDbContext dbContext) : base(dbContext)
        {
            _dBContext = dbContext;
        }

        public async Task<IList<ConfreneceRoom>> GetActiveRooms()
        {
            return await _dBContext.ConfreneceRoom.Where(x => x.IsActive).ToListAsync();
        }
        public async Task DeleteBooking(long id)
        {
            var booking = await _dBContext.ConfreneceRoom.FindAsync(id).ConfigureAwait(false);
            _dBContext.ConfreneceRoom.Remove(booking);
            await _dBContext.SaveChangesAsync().ConfigureAwait(false);

        }

        public async Task<ConfreneceRoom> Store(ConfreneceRoom model) 
        {
            var room=   _dBContext.ConfreneceRoom.Find(model.Id);
            ConfreneceRoom result = null;
            if (room != null)
            {
                room.Location = model.Location;
                room.RoomTypeId = model.RoomTypeId;
                room.IsActive = model.IsActive;
                room.Capacity = model.Capacity;
                room.Name = model.Name;
                room.ModifiedBy = model.CreatedBy;
                result = room;
            }
            else
            {
                 result = _dBContext.ConfreneceRoom.Add(
                       new ConfreneceRoom
                       {
                           Id = model.Id,
                           Location = model.Location,
                           RoomTypeId = model.RoomTypeId,
                           IsActive = model.IsActive,
                           Capacity = model.Capacity,
                           Name = model.Name,
                           CreatedBy = model.CreatedBy,
                           CreationTs = DateTime.Now,
                           StatusType = StatusType.Enabled
                       });
            }
            await _dBContext.SaveChangesAsync().ConfigureAwait(false);
            return result;
        }

    }
}
