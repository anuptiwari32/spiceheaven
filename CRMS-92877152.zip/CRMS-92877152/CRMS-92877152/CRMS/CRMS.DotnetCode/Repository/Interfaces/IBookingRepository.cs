﻿using Data.Entity;
using Data.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
   public interface IBookingRepository : IGenericRepository<Booking>
    {
        Task<IList<Booking>>GetBookings(string booking);
        Task SaveBooking(BookingViewModel booking);
        Task DeleteBooking(long id);
        Task CancelBooking(Booking booking);
    }
}
