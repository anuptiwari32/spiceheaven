﻿using Data.Entity;
using Data.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Interfaces
{
    public interface IRoomRepository : IGenericRepository<ConfreneceRoom>
    {
        Task<IList<ConfreneceRoom>> GetActiveRooms();
        Task<ConfreneceRoom> Store(ConfreneceRoom room);
        Task DeleteBooking(long id);
    }
}
