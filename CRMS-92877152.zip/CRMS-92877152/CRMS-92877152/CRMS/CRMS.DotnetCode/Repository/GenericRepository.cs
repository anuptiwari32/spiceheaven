﻿using Data;
using Data.Entity;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class GenericRepository<T> : IGenericRepository<T> where T : BaseEntity
    {
        private CRMSDbContext _dbContext;
        private readonly DbSet<T> _dbSet;
        public GenericRepository(CRMSDbContext dbContext)
        {
            _dbContext = dbContext;
            _dbSet = dbContext.Set<T>();
        }

        public async Task<IEnumerable<T>> Get(Expression<Func<T, bool>> filter = null, 
            Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includeProperties = "")
        {
            IQueryable<T> query = _dbSet;
          return await query.ToListAsync();
        }

        public  Task<T> GetByID(long id) //async
        {
			return Task.FromResult<T>(null);
		}

        public void Insert(T entity) //async
        {
			 //  code
        }

        public Task  Delete(long id) //async
       {
            // code
            var ent = this._dbContext.Set<T>().Find(id);

            if (ent != null)
            {
                this._dbContext.Set<T>().Remove(ent);
            }

            return Task.FromResult<T>(null);

		}

		public void Delete(T entityToDelete)
        {
			// code

		}

		public void Update(T entityToUpdate)
        {
			// code
		}

		public  void Save(T entity)
        {
           _dbContext.Set<T>().Add(entity);
           _dbContext.SaveChanges();
            //_dbContext.Set<T>().Attach(entity);
            // code
        }
    }
}
