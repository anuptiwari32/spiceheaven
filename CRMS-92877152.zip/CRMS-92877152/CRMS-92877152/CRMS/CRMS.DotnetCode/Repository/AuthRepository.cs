﻿using Data;
using Data.Entity;
using Data.ViewModel;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
   public class AuthRepository: IAuthRepository
    {
        private CRMSDbContext dbContext;
        private UserManager<User> _userManager;

        public AuthRepository(CRMSDbContext context, UserManager<User> userManager)
        {
            dbContext = context;
            _userManager = userManager;
        }

        public async  Task<User> FindUser(string userName, string password)
		{

           
                var user = dbContext.Users.Where(x => x.UserName.Equals(userName)).FirstOrDefault();

                if (user == null)
                {
                    return null;
                }

                var isPasswordValid = await _userManager.CheckPasswordAsync((User)user, password);

                if (!isPasswordValid)
                {
                    return null;
                }

                return (User)user;
          
        }

        public async Task<IdentityResult> Register(RegisterViewModel model) //async
        {
            var result = await _userManager.CreateAsync(
                   new User() { 
                       UserName = model.UserName, 
                       Email = model.Email,
                       Firstname = model.Firstname,
                       Lastname= model.Lastname,
                       UserType = model.UserType,
                       PhoneNumber = model.PhoneNumber,
                       EmpID = model.EmpID,
                       EmpAddress = model.EmpAddress
                   },
                   model.Password
               );

            return result;
        }
    }
}
